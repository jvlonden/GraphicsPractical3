Daan Weller 3988651
Jordy Van Londen 3953750
Chrit Hameleers 3978125

This is how we divided the work:
Chrit: spotlight code and support for mulitple spotlights, reimplementation of grayscale
Daan: Grayscale(begin) and mulitple lights(begin)
Jordy: Cook-Torrance/ frustrum culling and multiple lights(finished)


Sources:
spotlight: http://xboxforums.create.msdn.com/forums/p/3303/16481.aspx
postprocessing: http://rbwhitaker.wikidot.com/post-processing-effects

Included assigments:
E1 Cook-Torrance
E2 Spotlight
E3 Multpile Spotlights
E4 Frustrum Culling
E5 Grayscale postprocessing

Where to find the assignments:

When you run the program you can cycle between scenes. One with a single spotlight and one with many spotlights.
Cycle using spacebar.
E1 is found in both scenes. Cook torrance is implemented for all the spotlights.
E2/E3 spotlights can be found in both scenes. there is one scene with only one spotlight, and one with randomizable spotlights.
E4 frustrum culling is implemented globally and its results can be tracked in the top left corner.
E5 Grayscale Postprocessing can be activated by pressing G anywhere.



